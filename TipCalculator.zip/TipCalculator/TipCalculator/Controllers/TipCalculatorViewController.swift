//
//  TipCalculatorViewController.swift
//  TipCalculator
//
//  Created by David Boyd on 5/17/21.
//

import UIKit

class TipCalculatorViewController: UIViewController {
    
    //MARK: -Outlets
    @IBOutlet weak var billTextField: UITextField!
    @IBOutlet weak var tipPercentSegmentedControl: UISegmentedControl!
    @IBOutlet weak var numberOfPersonSlider: UISlider!
    @IBOutlet weak var numberOfPersonLabel: UILabel!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipPerPersonLabel: UILabel!
    @IBOutlet weak var totalPerPersonLabel: UILabel!
    
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    //MARK: -Actions
    @IBAction func calculateButtonTapped(_ sender: Any) {
        calculate()
    }
    @IBAction func numberOfPersonSliderTapped(_ sender: Any) {
        let intValue = Int(numberOfPersonSlider.value)
        self.numberOfPersonLabel.text = String(intValue)
    }
    
    //MARK: - Functions
    func calculate() {
        if self.billTextField.isFirstResponder {
            self.billTextField.resignFirstResponder()
        }
        
        guard let billAmountString = self.billTextField.text,
              let billAmount = Double(billAmountString) else {return}
        
        let roundedBillAmount = (100 * billAmount).rounded() / 100
        
        var precentage: Double
        switch tipPercentSegmentedControl.selectedSegmentIndex {
        case 0 :
            precentage = 0.15
        case 1:
            precentage = 0.18
        case 2:
            precentage = 0.2
        default:
            preconditionFailure("Unexpected index")
        }
        
        let tipAmount = roundedBillAmount * precentage
        let roundedTipAmount = (100 * tipAmount).rounded() / 100
        
        self.tipLabel.text = "$" + String(format: "%.2f", roundedTipAmount)
        
        let total = roundedBillAmount + roundedTipAmount
        self.totalLabel.text = "$" + String(format: "%.2f", total)
        
        let numberOfPerson = numberOfPersonSlider.value
        let tipPerPerson = roundedTipAmount / Double(numberOfPerson)
        let roundedTipPerPerson = (100 * tipPerPerson).rounded() / 100
        self.tipPerPersonLabel.text = "$" + String(format: "%.2f", roundedTipPerPerson)
        
        let totalPerPerson = total / Double(numberOfPerson)
        let roundedtotalPerPerson = (100 * totalPerPerson).rounded() / 100
        self.totalPerPersonLabel.text = "$" + String(format: "%.2f", roundedtotalPerPerson)
    }
    
    
}//End of class
